import { Humains } from "../abstract/Humains";

export class Clients extends Humains {
    
    private numeroClient: number;

    constructor(prenom: string, age: number, name: string, job: string, numeroClient: number) {
        super(name, age, job, prenom);
        this.numeroClient = numeroClient;
    }


    parler(): void {
        console.log("Je parle");
    }
    interagir(): void {
        console.log( "Je peux interagir");
    }

    get NumeroClient() : number {
        return this.numeroClient;
    }

    set NumeroClient(numeroClient : number) {
        this.numeroClient = numeroClient;
    }

    
}