import { Humains } from "../abstract/Humains";

export class Employees extends Humains {
    private fonction: string;
    
   
    
    constructor(prenom: string, age: number, name: string, job: string, numeroClient: number,fonction: string) {
        super(name, age, job, prenom);
        this.fonction = fonction;
    }
        
    parler(): void {
        console.log("Je suis une employe et je parle");
    }
    interagir(): void {
        console.log( "Je peux interagir");
    }

    get Fonction() : string {
        return this.fonction;
    }

    set Fonction(fonction : string) {
        this.fonction = fonction;
    }
    

}
