import { zebre } from "./animal/zebre";
import { Clients } from "./humains/clients";
import {Chat} from "./animal/Chat";
import { Employees } from "./humains/Empoyees";

class Main {
    public static main(): void {
        let zebre1 = new zebre("zebre1", 5, 100, "zebre");

        let chat= new Chat("chat", 3, 50, "chat", "foret");
        let clients = new Clients("clients", 25, "clients", "clients", 1);
        let employees = new Employees("employees", 25, "employees", "employees", 1, "employees");
        
        console.log(zebre1);
        console.log(chat);
        console.log(clients);
        console.log(employees);

    }}