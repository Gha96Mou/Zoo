export class zebre{
    private name : String;
    private age : Number;
    private height : Number;
    private species : String;

    constructor(name : String, age : Number, height : Number, species : String) {
        this.name = name;
        this.age = age;
        this.height = height;
        this.species = species;
    }

    get Name() : String {
        return this.name;
    }

    get Age() : Number {
        return this.age;
    }

    get Height() : Number {
        return this.height;
    }

    get Species() : String {
        return this.species;
    }
}
