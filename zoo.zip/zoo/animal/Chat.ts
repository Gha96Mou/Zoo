import { Animal } from "../abstract/animal";

export class Chat extends Animal {
    seNourrir(): void {
        console.log("Le chat mange du poisson");
       
    }
    communiquer(): void {
        console.log("Je miaule");
       
    }
    seDeplacer(): void {
        console.log("Je me balade");
        
    }

    constructor(name : String, age : Number, taille : Number, espece : String, habitat : String) {
        super(name, age, taille, espece, habitat);
    }
    
}

  