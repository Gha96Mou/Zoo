export abstract class Animal { 
    protected nom : String;
    public age: Number ;
    protected taille : Number;
    protected espece : String;
    protected habitat : String;

    constructor(nom : String, age : Number, taille : Number, espece : String, habitat : String) {
        this.nom = nom;
        this.age = age;
        this.taille = taille;
        this.espece = espece;
        this.habitat = habitat;
    }

    abstract seNourrir(): void;
    

    abstract communiquer(): void;
  
    abstract seDeplacer(): void;

    get Nom() : String {
        return this.nom;
    }

    get Age() : Number {
        return this.age;
    }

    get Taille() : Number {
        return this.taille;
    }
    
    get Espece() : String {
        return this.espece;
    }

    get Habitat() : String {
        return this.habitat;
    }

    set Nom(nom : String) {
        this.nom = nom;
    }

    set Age(age : Number) {
        this.age = age;
    }

    set Taille(taille : Number) {
        this.taille = taille;
    }

    set Espece(espece : String) {
        this.espece = espece;
    }
    

}