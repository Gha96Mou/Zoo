export abstract class  Humains {
    private name : String;
  protected prenom: string;
  protected age: number;
    private job : String;
    
    constructor(name : String, age : Number, job : String,  prenom: string) {
        this.name = name;
        this.job = job;
        this.prenom = prenom;
  }



  abstract parler(): void;

  abstract interagir(): void;

    
    get Name() : String {
        return this.name;
    }
    
    get Age() : Number {
        return this.age;
    }

    get Job() : String {
        return this.job;
    }
    
    
    set Name(name : String) {
        this.name = name;
    }    
   
    set Job(job : String) {
        this.job = job;
    }
  
}